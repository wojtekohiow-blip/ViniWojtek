package pl.viniwojtek.viniclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ViniClient implements ClientModInitializer {
    public static boolean freelook = false;
    public static boolean crosshairIndicator = true;
    public static boolean healthIndicator = true;
    public static boolean physicsItems3d = true;
    public static boolean extraAnimations = true;
    public static boolean fullbright = false;

    private static KeyBinding menuKey;
    private static double previousGamma = 1.0;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.viniclient.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.viniclient"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ViniMenuScreen());
            }
            if (client.options != null) {
                double current = client.options.getGamma().getValue();
                if (fullbright && current < 16.0) {
                    previousGamma = current;
                    client.options.getGamma().setValue(16.0);
                } else if (!fullbright && current >= 16.0) {
                    client.options.getGamma().setValue(Math.min(previousGamma, 1.0));
                }
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> renderHud(MinecraftClient.getInstance(), drawContext));
    }

    private static void renderHud(MinecraftClient client, DrawContext context) {
        if (client.player == null || client.options.hudHidden) return;
        int x = client.getWindow().getScaledWidth();
        int y = client.getWindow().getScaledHeight();
        if (crosshairIndicator) context.fill(x / 2 - 1, y / 2 - 1, x / 2 + 2, y / 2 + 2, 0xCC55FF55);
        if (healthIndicator) {
            float health = client.player.getHealth();
            float absorption = client.player.getAbsorptionAmount();
            String label = "HP " + (int)Math.ceil(health) + (absorption > 0 ? " +" + (int)Math.ceil(absorption) : "");
            context.drawTextWithShadow(client.textRenderer, Text.literal(label), 8, y - 28, 0xFFFFFFFF);
        }
    }
}
