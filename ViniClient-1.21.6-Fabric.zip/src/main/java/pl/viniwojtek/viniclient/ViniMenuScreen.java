package pl.viniwojtek.viniclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ViniMenuScreen extends Screen {
    public ViniMenuScreen() { super(Text.literal("ViniClient — Funkcje")); }

    @Override
    protected void init() {
        int centerX = width / 2;
        int startY = height / 2 - 86;
        int w = 220, h = 20, gap = 24;

        addToggle(centerX, startY, w, h, "Freelook", () -> ViniClient.freelook, v -> ViniClient.freelook = v);
        addToggle(centerX, startY + gap, w, h, "Crosshair indicator", () -> ViniClient.crosshairIndicator, v -> ViniClient.crosshairIndicator = v);
        addToggle(centerX, startY + gap * 2, w, h, "Health indicator", () -> ViniClient.healthIndicator, v -> ViniClient.healthIndicator = v);
        addToggle(centerX, startY + gap * 3, w, h, "Physik items 3D", () -> ViniClient.physicsItems3d, v -> ViniClient.physicsItems3d = v);
        addToggle(centerX, startY + gap * 4, w, h, "Dodatkowe animacje", () -> ViniClient.extraAnimations, v -> ViniClient.extraAnimations = v);
        addToggle(centerX, startY + gap * 5, w, h, "Fullbright", () -> ViniClient.fullbright, v -> ViniClient.fullbright = v);

        addDrawableChild(ButtonWidget.builder(Text.literal("Zamknij"), button -> close())
                .dimensions(centerX - w / 2, startY + gap * 6, w, h).build());
    }

    private void addToggle(int centerX, int y, int width, int height, String label,
                           java.util.function.BooleanSupplier getter,
                           java.util.function.Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(toggleText(label, getter.getAsBoolean()), b -> {
            setter.accept(!getter.getAsBoolean());
            b.setMessage(toggleText(label, getter.getAsBoolean()));
        }).dimensions(centerX - width / 2, y, width, height).build());
    }

    private Text toggleText(String label, boolean enabled) {
        return Text.literal(label + ": " + (enabled ? "§aWŁ." : "§cWYŁ."));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 112, 0xFFFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public boolean shouldPause() { return false; }
}
