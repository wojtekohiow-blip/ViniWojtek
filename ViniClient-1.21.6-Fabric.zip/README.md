# ViniClient — Minecraft 1.21.6 (Fabric)

## Wymagania
- Minecraft Java Edition 1.21.6
- Java 21
- Fabric Loader oraz Fabric API dla 1.21.6

## Budowanie
Otwórz projekt w IntelliJ IDEA i uruchom `gradle build`. Plik JAR pojawi się w `build/libs/`.
Skopiuj go do `.minecraft/mods` razem z Fabric API.

## Sterowanie
- Prawy Shift — menu ViniClient.

## Ważne
To projekt źródłowy, a nie gotowy skompilowany JAR. Crosshair Indicator, Health Indicator i podstawowy Fullbright są zaimplementowane. Freelook, Physik Items 3D i dodatkowe animacje mają obecnie tylko przełączniki — ich efekty wymagają dalszego kodu. Wartości wersji zależności zostały ustawione dla 1.21.6, ale projekt nie został tutaj skompilowany ani przetestowany.
